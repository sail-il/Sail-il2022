#!/usr/bin/env python3.7.4
import os
import sys
import csv
from pathlib import Path
import argparse
import re
import shutil
import glob


def get_iou(bb1, bb2):
    """
    Calculate the Intersection over Union (IoU) of two bounding boxes.

    Parameters
    ----------
    bb1 : dict
        Keys: {'x1', 'x2', 'y1', 'y2'}
        The (x1, y1) position is at the top left corner,
        the (x2, y2) position is at the bottom right corner
    bb2 : dict
        Keys: {'x1', 'x2', 'y1', 'y2'}
        The (x, y) position is at the top left corner,
        the (x2, y2) position is at the bottom right corner

    Returns
    -------
    float
        in [0, 1]
    """
    #assert bb1['y2']>0
    #assert bb2['y2']>0
    #assert bb1['y2']<1
    #assert bb2['y2']<1
    #assert bb1['x2']>0
    #assert bb2['x2']>0
    ##assert bb1['x2']<1
    #assert bb2['x2']<1
    #assert bb1['y1']>0
    #assert bb2['y1']>0
    #assert bb1['y1']<1
    #assert bb2['y1']<1
    ##assert bb1['x1']>0
    ##assert bb2['x1']>0
    #assert bb1['x1']<1
    #assert bb2['x1']<1
    ##if (bb1['x1'] > bb1['x2']) or (bb1['y1'] > bb1['y2']) or (bb2['x1'] > bb2['x2']) or (bb2['y1'] < bb2['y2']):
    ##    return 0
    ##assert bb1['x1'] < bb1['x2']
    ##assert bb1['y1'] > bb1['y2']
    #assert bb2['x1'] < bb2['x2']
    #assert bb2['y1'] > bb2['y2']

    # determine the coordinates of the intersection rectangle
    x_left = max(bb1['x1'], bb2['x1'])
    y_top = max(bb1['y1'], bb2['y1'])
    x_right = min(bb1['x2'], bb2['x2'])
    y_bottom = min(bb1['y2'], bb2['y2'])

    if x_right < x_left or y_bottom < y_top:
        return 0.0

    # The intersection of two axis-aligned bounding boxes is always an
    # axis-aligned bounding box
    intersection_area = (x_right - x_left) * (y_bottom - y_top)

    # compute the area of both AABBs
    bb1_area = (bb1['x2'] - bb1['x1']) * (bb1['y2'] - bb1['y1'])
    bb2_area = (bb2['x2'] - bb2['x1']) * (bb2['y2'] - bb2['y1'])

    # compute the intersection over union by taking the intersection
    # area and dividing it by the sum of prediction + ground-truth
    # areas - the interesection area
    iou = intersection_area / float(bb1_area + bb2_area - intersection_area)
    assert iou >= 0.0
    assert iou <= 1.0
    return iou


#---------------------------
def draw_matrix(y_test,y_pred):
    #matrix = [7*[0,0,0,0,0,0,0]]
    matrix = [[0 for i in range(7)] for j in range(7)]

    for i in range(len(y_test)):
        matrix[int(y_test[i])][int(y_pred[i])]+=1
    print(matrix)
   


#   currentDataClass = [1,3,3,2,5,5,3,2,1,4,3,2,1,1,2]    
#predictedClass = [1,2,3,4,2,3,3,2,1,2,3,1,5,1,1]
#
#classes = int(max(currentDataClass) - min(currentDataClass)) + 1 #find number of classes
#
#counts = [[sum([(currentDataClass[i] == true_class) and (predictedClass[i] == pred_class) 
#                for i in range(len(currentDataClass))])
#           for pred_class in range(1, classes + 1)] 
#           for true_class in range(1, classes + 1)]
#counts

#---------main-------------

def main():
    final_data=[]
    y_gt=[]
    y_pred=[]
    #basepath = "."
    #predictions = os.listdir('C:\Users\dporatpu\OneDrive - Intel Corporation\Desktop\studies\project\Object-Detection-Evaluation-Tool-master\sample\prediction')
    #basepath = r"C:\"
    predictions = os.listdir("C:\prediction")
    gts = os.listdir("C:\gts")
    raw_data_array = [0,1]
    file_array = [predictions,gts]
    for file_index in range(len(file_array[0])):
        for dir_index in range(len(file_array)):
            if dir_index==0:
                basepath = "C:\prediction"
            if dir_index==1:
                basepath = "C:\gts"
            with open(f"{basepath}\{file_array[dir_index][file_index]}",'r') as f:
                raw_data_array[dir_index] = f.read().splitlines()
        for i in range(len(raw_data_array[0])):
            for j in range(len(raw_data_array[1])):
                bb_keys = ['x1','x2','y1','y2']
                pred_file = file_array[0][i]
                gt_file = file_array[1][j]
                pred_raw=[float(x) for x in raw_data_array[0][i].split()]
                pred_list = [pred_raw[1]-pred_raw[3]/2,pred_raw[1]+pred_raw[3]/2,pred_raw[2]-pred_raw[4]/2,pred_raw[2]+pred_raw[4]/2]
                gt_raw=[float(x) for x in raw_data_array[1][j].split()]
                gt_list = [gt_raw[1]-gt_raw[3]/2,gt_raw[1]+gt_raw[3]/2,gt_raw[2]-gt_raw[4]/2,gt_raw[2]+gt_raw[4]/2]
                pred_object = pred_raw[0]
                pred_bb = dict(zip(bb_keys,pred_list))
                gt_object = gt_raw[0]
                gt_bb = dict(zip(bb_keys,gt_list))
               # assert pred_bb['x1']>0

                iou = get_iou(pred_bb,gt_bb)
                if iou>0.5:
                    #compare_tuple = (pred_object,gt_object)
                    #final_data.append(compare_tuple)
                    y_gt.append(gt_object)
                    y_pred.append(pred_object)
    draw_matrix(y_gt,y_pred)

    print(final_data)
#----------------------
if __name__ == '__main__':
   # yaml.warnings({'YAMLLoadWarning': False})
    main()
